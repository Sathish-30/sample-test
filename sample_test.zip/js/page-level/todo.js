$(".todo").todoList({
    items: [
        'Meeting with Amanda and team.',
        'Assign task for Smith.',
        'Meeting with client and CEO.',
        'Start new task with mark.',
        'Complete milestone 3 and update.'
    ]
});
