
$(window).on("load",function(){
      $(".select2").select2();
      $(".select2.classic").select2({ theme: "classic"});
});
